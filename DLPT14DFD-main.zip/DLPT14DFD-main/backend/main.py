# main.py

from fastapi import FastAPI, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from services.deepfake_detector import DeepfakeDetector
from services.file_handler import FileHandler
import uvicorn
import logging
from pathlib import Path

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="Deepfake Detection API")

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Create necessary directories
static_dir = Path("temp")
static_dir.mkdir(exist_ok=True)

# Mount static files directory for serving annotated images/videos
app.mount("/media", StaticFiles(directory=static_dir), name="media")

# Initialize services
try:
    # Make sure to update the model path accordingly
    detector = DeepfakeDetector(model_path="models/fixed_model.h5")
    file_handler = FileHandler()
    logger.info("Services initialized successfully")
except Exception as e:
    logger.error(f"Error initializing services: {e}")
    raise

@app.post("/api/analyze")
async def analyze_media(file: UploadFile = File(...)):
    try:
        logger.info(f"Received file: {file.filename}")
        
        # Save uploaded file
        file_path = await file_handler.save_file(file)
        logger.info(f"File saved to: {file_path}")
        
        # Process the file using the new deepfake detector logic
        result = await detector.analyze_media(file_path)
        logger.info("Analysis completed successfully")
        
        # Modify the URL to include the full backend URL if needed
        if result.get("annotatedUrl"):
            result["annotatedUrl"] = f"http://localhost:8000{result['annotatedUrl']}"
        
        # For non-video files, perform cleanup immediately.
        if not file.filename.lower().endswith(('.mp4', '.avi', '.mov', '.webm')):
            file_handler.cleanup(file_path)
        else:
            logger.info("Video file will be retained temporarily for processing")
        
        return JSONResponse(content=result)
    except Exception as e:
        logger.error(f"Error processing request: {e}")
        return JSONResponse(
            status_code=500,
            content={"error": str(e)}
        )

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
