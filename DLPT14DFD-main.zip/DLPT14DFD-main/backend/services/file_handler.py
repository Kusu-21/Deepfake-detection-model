
import os
from fastapi import UploadFile
from pathlib import Path
import shutil
import logging

logger = logging.getLogger(__name__)

class FileHandler:
    def __init__(self):
        self.upload_dir = Path("temp")
        self.upload_dir.mkdir(exist_ok=True)
        logger.info(f"Initialized FileHandler with upload directory: {self.upload_dir}")

    async def save_file(self, file: UploadFile) -> str:
        """Save uploaded file and return its path."""
        try:
            # Create a unique filename to prevent overwriting
            file_path = self.upload_dir / f"upload_{hash(file.filename)}_{file.filename}"
            
            with open(file_path, "wb") as buffer:
                shutil.copyfileobj(file.file, buffer)
            
            logger.info(f"Successfully saved file to: {file_path}")
            return str(file_path)
        except Exception as e:
            logger.error(f"Error saving file {file.filename}: {e}")
            raise

    def cleanup(self, file_path: str):
        """Clean up temporary files."""
        try:
            if os.path.exists(file_path):
                os.remove(file_path)
                logger.info(f"Cleaned up file: {file_path}")
        except Exception as e:
            logger.error(f"Error cleaning up file {file_path}: {e}")
