import os
import cv2
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import load_model
from tensorflow.keras.applications import InceptionV3
from tensorflow.keras.models import Model
from tensorflow.keras import layers
from pathlib import Path

# Constants
IMG_SIZE = 224
MAX_SEQ_LENGTH = 20
NUM_FEATURES = 2048

# Custom GRU class that overrides call() to check the mask type
class FixedGRU(tf.keras.layers.GRU):
    def call(self, inputs, mask=None, training=None, initial_state=None):
        # If the mask is not a Tensor (e.g. a list of strings), ignore it.
        if mask is not None and not isinstance(mask, tf.Tensor):
            mask = None
        return super().call(inputs, mask=mask, training=training, initial_state=initial_state)

def fix_gru_layer(*args, **kwargs):
    """Return an instance of our custom GRU layer instead of the standard one."""
    if 'units' in kwargs:
        return FixedGRU(
            units=kwargs.get('units'),
            return_sequences=kwargs.get('return_sequences', False),
            activation=kwargs.get('activation', 'tanh'),
            recurrent_activation=kwargs.get('recurrent_activation', 'sigmoid'),
            use_bias=kwargs.get('use_bias', True),
            kernel_initializer=kwargs.get('kernel_initializer', 'glorot_uniform'),
            recurrent_initializer=kwargs.get('recurrent_initializer', 'orthogonal'),
            bias_initializer=kwargs.get('bias_initializer', 'zeros'),
            dropout=kwargs.get('dropout', 0.0),
            recurrent_dropout=kwargs.get('recurrent_dropout', 0.0),
            return_state=kwargs.get('return_state', False),
            go_backwards=kwargs.get('go_backwards', False),
            stateful=kwargs.get('stateful', False),
            unroll=kwargs.get('unroll', False)
        )
    return FixedGRU(128, return_sequences=True)

def build_feature_extractor():
    """Creates a feature extractor using InceptionV3 (pretrained on ImageNet)."""
    feature_extractor = InceptionV3(
        weights="imagenet",
        include_top=False,
        pooling="avg",
        input_shape=(IMG_SIZE, IMG_SIZE, 3),
    )
    preprocess_input = tf.keras.applications.inception_v3.preprocess_input
    inputs = layers.Input((IMG_SIZE, IMG_SIZE, 3))
    preprocessed = preprocess_input(inputs)
    outputs = feature_extractor(preprocessed)
    return Model(inputs, outputs, name="feature_extractor")

# Load the feature extractor once at initialization
feature_extractor = build_feature_extractor()

def crop_center_square(frame):
    """Crops an image to a square based on the smallest dimension."""
    y, x = frame.shape[0:2]
    min_dim = min(y, x)
    start_x = (x // 2) - (min_dim // 2)
    start_y = (y // 2) - (min_dim // 2)
    return frame[start_y : start_y + min_dim, start_x : start_x + min_dim]

def preprocess_image(image_path):
    """Reads and preprocesses an image for deepfake classification."""
    img = cv2.imread(image_path)
    img = crop_center_square(img)
    img = cv2.resize(img, (IMG_SIZE, IMG_SIZE))
    img = img[:, :, [2, 1, 0]]  # Convert BGR to RGB
    img = np.expand_dims(img, axis=0)  # Add batch dimension
    return img

def extract_features_from_image(image_path):
    """Extracts image features using the pretrained InceptionV3 model."""
    img = preprocess_image(image_path)
    features = feature_extractor.predict(img)
    return features

def load_video(path, max_frames=MAX_SEQ_LENGTH, resize=(IMG_SIZE, IMG_SIZE)):
    """Extracts and preprocesses frames from a video file."""
    cap = cv2.VideoCapture(path)
    frames = []
    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            frame = crop_center_square(frame)
            frame = cv2.resize(frame, resize)
            frame = frame[:, :, [2, 1, 0]]  # Convert BGR to RGB
            frames.append(frame)
            if len(frames) == max_frames:
                break
    finally:
        cap.release()
    return np.array(frames)

def prepare_single_video(frames):
    """Extracts features from video frames and pads them if necessary."""
    frames = frames[None, ...]  # Add batch dimension
    frame_mask = np.zeros((1, MAX_SEQ_LENGTH), dtype="bool")
    frame_features = np.zeros((1, MAX_SEQ_LENGTH, NUM_FEATURES), dtype="float32")
    
    for i, batch in enumerate(frames):
        video_length = batch.shape[0]
        length = min(MAX_SEQ_LENGTH, video_length)
        for j in range(length):
            frame_features[i, j, :] = feature_extractor.predict(batch[None, j, :])
        frame_mask[i, :length] = 1  # 1 = real frame, 0 = padding
    
    return frame_features, frame_mask

class DeepfakeDetector:
    def __init__(self, model_path: str):
        """
        Initialize the detector by loading the fixed model using the custom GRU layer.
        """
        self.model = load_model(model_path, custom_objects={'GRU': fix_gru_layer})
        print("✅ Model loaded successfully!")
    
    async def analyze_media(self, file_path: str) -> dict:
        """
        Determine file type (image/video) based on file extension and process accordingly.
        """
        ext = Path(file_path).suffix.lower()
        if ext in ['.jpg', '.jpeg', '.png']:
            return self._analyze_image(file_path)
        elif ext in ['.mp4', '.avi', '.mov', '.webm']:
            return self._analyze_video(file_path)
        else:
            raise ValueError("Unsupported file type")
    
    def _analyze_image(self, image_path: str) -> dict:
        """Classify an image file as REAL or FAKE."""
        features = extract_features_from_image(image_path)
        # Expand and tile to match expected shape: (1, MAX_SEQ_LENGTH, NUM_FEATURES)
        features = np.expand_dims(features, axis=1)
        features = np.tile(features, (1, MAX_SEQ_LENGTH, 1))
        # Use the dummy mask as in the original code
        frame_mask = np.ones((1, MAX_SEQ_LENGTH), dtype="bool")
        
        # Call predict with two inputs; our FixedGRU will ignore the mask if it isn’t a proper tensor.
        prediction = self.model.predict([features, frame_mask])[0][0]
        label = "FAKE" if prediction >= 0.5 else "REAL"
        annotated_url = self._annotate_media(image_path, label)
        
        return {
            "label": label,
            "confidence": float(prediction),
            "annotatedUrl": annotated_url,
        }
    
    def _analyze_video(self, video_path: str) -> dict:
        """Classify a video file as REAL or FAKE."""
        frames = load_video(video_path)
        frame_features, frame_mask = prepare_single_video(frames)
        
        prediction = self.model.predict([frame_features, frame_mask])[0][0]
        label = "FAKE" if prediction >= 0.5 else "REAL"
        annotated_url = self._annotate_media(video_path, label, is_video=True)
        
        return {
            "label": label,
            "confidence": float(prediction),
            "annotatedUrl": annotated_url,
        }
    
    def _annotate_media(self, file_path: str, label: str, is_video: bool = False) -> str:
        """
        Annotate the image (or video thumbnail) with the prediction label.
        The annotated file is saved in the 'temp' directory.
        """
        if is_video:
            # For videos, save the annotated thumbnail as a JPG image
            annotated_path = Path("temp") / f"annotated_{Path(file_path).stem}.jpg"
        else:
            # For images, keep the original extension (if supported)
            annotated_path = Path("temp") / f"annotated_{Path(file_path).name}"
        
        if not is_video:
            img = cv2.imread(file_path)
            if img is not None:
                cv2.putText(
                    img,
                    f"{label}",
                    (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    1,
                    (0, 255, 0) if label == "REAL" else (0, 0, 255),
                    2,
                    cv2.LINE_AA
                )
                cv2.imwrite(str(annotated_path), img)
        else:
            # For video, extract the first frame as a thumbnail and annotate it
            frames = load_video(file_path, max_frames=1)
            if len(frames) > 0:
                thumb = frames[0]
                cv2.putText(
                    thumb,
                    f"{label}",
                    (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    1,
                    (0, 255, 0) if label == "REAL" else (0, 0, 255),
                    2,
                    cv2.LINE_AA
                )
                cv2.imwrite(str(annotated_path), thumb)
        
        # Return a URL that the frontend can use (matches your static mount in main.py)
        return f"/media/{annotated_path.name}"
