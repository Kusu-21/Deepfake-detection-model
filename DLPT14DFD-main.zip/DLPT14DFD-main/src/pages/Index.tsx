
import { Link } from "react-router-dom";
import { Upload, Shield, Zap } from "lucide-react";
import Navbar from "@/components/layout/Navbar";

const Index = () => {
  const features = [
    {
      icon: <Upload className="w-6 h-6 text-cyan-bright" />,
      title: "Easy Upload",
      description: "Simply drag and drop your media files for instant analysis",
    },
    {
      icon: <Shield className="w-6 h-6 text-purple-deep" />,
      title: "Advanced AI",
      description: "Powered by state-of-the-art deepfake detection algorithms",
    },
    {
      icon: <Zap className="w-6 h-6 text-cyan-bright" />,
      title: "Real-time Results",
      description: "Get immediate feedback on content authenticity",
    },
  ];

  return (
    <div className="min-h-screen bg-dark">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-20 pb-32 relative overflow-hidden">
        <div className="hero-gradient absolute inset-0" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center pt-20 pb-16">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              <span className="text-gradient">Unmasking the Truth</span>
              <br />
              <span className="text-white">AI-Powered Deepfake Detection</span>
            </h1>
            <p className="text-gray-400 text-lg md:text-xl max-w-2xl mx-auto mb-8">
              Upload your media and let our advanced AI technology verify its authenticity
              with precision and reliability.
            </p>
            <Link
              to="/upload"
              className="inline-flex items-center px-6 py-3 rounded-lg bg-gradient-to-r from-cyan-bright to-purple-deep text-white font-semibold transform transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-cyan-bright/20"
            >
              Start Detection
            </Link>
          </div>

          {/* Features Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
            {features.map((feature, index) => (
              <div
                key={index}
                className="glass-panel p-6 neon-glow animate-float"
                style={{
                  animationDelay: `${index * 0.2}s`,
                }}
              >
                <div className="flex flex-col items-center text-center">
                  <div className="mb-4">{feature.icon}</div>
                  <h3 className="text-xl font-semibold mb-2 text-white">
                    {feature.title}
                  </h3>
                  <p className="text-gray-400">{feature.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Index;
