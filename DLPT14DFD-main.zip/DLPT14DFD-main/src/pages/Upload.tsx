
import { useState } from "react";
import { Upload as UploadIcon, Image, Video, X } from "lucide-react";
import Navbar from "@/components/layout/Navbar";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

type FileType = "image" | "video" | null;

interface AnalysisResult {
  isAuthentic: boolean;
  confidence: number;
  annotatedUrl: string;
  faces: Array<{
    x: number;
    y: number;
    width: number;
    height: number;
    label: "REAL" | "FAKE";
    confidence: number;
  }>;
}

const Upload = () => {
  const [file, setFile] = useState<File | null>(null);
  const [fileType, setFileType] = useState<FileType>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);

  const allowedImageTypes = ["image/jpeg", "image/png", "image/webp"];
  const allowedVideoTypes = ["video/mp4", "video/webm", "video/quicktime"];

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const validateFile = (file: File): boolean => {
    if (allowedImageTypes.includes(file.type)) {
      setFileType("image");
      return true;
    } else if (allowedVideoTypes.includes(file.type)) {
      setFileType("video");
      return true;
    }
    toast.error("Unsupported file type. Please upload an image or video.");
    return false;
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);

    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile && validateFile(droppedFile)) {
      setFile(droppedFile);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile && validateFile(selectedFile)) {
      setFile(selectedFile);
    }
  };

  const handleAnalyze = async () => {
    if (!file) return;

    setIsProcessing(true);
    const formData = new FormData();
    formData.append('file', file);

    try {
      // Replace with your actual API endpoint
      const response = await fetch('http://localhost:8000/api/analyze', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error('Analysis failed');
      }

      const data = await response.json();
      setResult({
        isAuthentic: data.isAuthentic,
        confidence: data.confidence,
        annotatedUrl: data.annotatedUrl,
        faces: data.faces || [],
      });
      
      toast.success("Analysis complete!");
    } catch (error) {
      console.error('Analysis error:', error);
      toast.error("Error processing file. Please try again.");
    } finally {
      setIsProcessing(false);
    }
  };

  const handleReset = () => {
    setFile(null);
    setFileType(null);
    setResult(null);
  };

  return (
    <div className="min-h-screen bg-dark">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-white">
            Upload Media for Analysis
          </h1>
          <p className="text-gray-400 mt-2">
            Drag and drop your image or video file to detect potential deepfakes
          </p>
        </div>

        {!result ? (
          <div className="max-w-2xl mx-auto">
            <div
              className={cn(
                "glass-panel p-8 text-center",
                "border-2 border-dashed border-gray-600 hover:border-cyan-bright transition-colors",
                isDragging && "border-cyan-bright",
                "cursor-pointer"
              )}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              onClick={() => document.getElementById("fileInput")?.click()}
            >
              <input
                type="file"
                id="fileInput"
                className="hidden"
                accept={[...allowedImageTypes, ...allowedVideoTypes].join(",")}
                onChange={handleFileInput}
              />
              
              {file ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-center gap-2">
                    {fileType === "image" ? (
                      <Image className="w-6 h-6 text-cyan-bright" />
                    ) : (
                      <Video className="w-6 h-6 text-cyan-bright" />
                    )}
                    <span className="text-white">{file.name}</span>
                  </div>
                  <button
                    className="px-4 py-2 bg-cyan-bright text-dark font-semibold rounded-lg hover:bg-opacity-90 transition-colors"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleAnalyze();
                    }}
                    disabled={isProcessing}
                  >
                    {isProcessing ? "Processing..." : "Analyze Now"}
                  </button>
                </div>
              ) : (
                <div>
                  <UploadIcon className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-300">
                    Drag and drop your file here, or click to browse
                  </p>
                  <p className="text-gray-500 text-sm mt-2">
                    Supported formats: JPG, PNG, WEBP, MP4, WEBM, MOV
                  </p>
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="max-w-4xl mx-auto glass-panel p-8">
            <div className="flex justify-between items-start mb-6">
              <div>
                <h2 className="text-2xl font-bold text-white mb-2">
                  Analysis Results
                </h2>
                <div className="flex items-center gap-4">
                  <span
                    className={cn(
                      "px-3 py-1 rounded-full text-sm font-medium",
                      result.isAuthentic
                        ? "bg-green-500/20 text-green-400"
                        : "bg-red-500/20 text-red-400"
                    )}
                  >
                    {result.isAuthentic ? "Authentic Content" : "Deepfake Detected"}
                  </span>
                  <span className="text-gray-400">
                    Confidence: {result.confidence.toFixed(2)}%
                  </span>
                </div>
              </div>
              <button
                onClick={handleReset}
                className="p-2 hover:bg-white/10 rounded-lg transition-colors"
              >
                <X className="w-5 h-5 text-gray-400" />
              </button>
            </div>
            
            <div className="relative rounded-lg overflow-hidden">
                <img
                  src={result.annotatedUrl}
                  alt="Analysis Result"
                  className="w-full h-auto"
                />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Upload;
