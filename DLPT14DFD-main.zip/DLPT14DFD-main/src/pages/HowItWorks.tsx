
import { Brain, Upload, Gauge } from "lucide-react";
import Navbar from "@/components/layout/Navbar";

const HowItWorks = () => {
  const steps = [
    {
      icon: <Upload className="w-12 h-12 text-cyan-bright" />,
      title: "Upload Media",
      description:
        "Simply upload your image or video file through our secure interface. We support various formats including JPG, PNG, WEBP for images and MP4, WEBM, MOV for videos.",
    },
    {
      icon: <Brain className="w-12 h-12 text-purple-deep" />,
      title: "AI Analysis",
      description:
        "Our advanced AI model analyzes the content for signs of manipulation, examining patterns and artifacts that might indicate deepfake alterations.",
    },
    {
      icon: <Gauge className="w-12 h-12 text-cyan-bright" />,
      title: "Get Results",
      description:
        "Receive detailed results showing whether the content is authentic or manipulated, along with a confidence score and visual annotations highlighting potential alterations.",
    },
  ];

  return (
    <div className="min-h-screen bg-dark">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-16">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gradient mb-4">
            How Our Deepfake Detection Works
          </h1>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Our platform uses state-of-the-art artificial intelligence to analyze media
            content and detect potential deepfake manipulations with high accuracy.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {steps.map((step, index) => (
            <div
              key={index}
              className="glass-panel p-8 text-center hover:scale-105 transition-transform"
            >
              <div className="flex justify-center mb-6">{step.icon}</div>
              <h3 className="text-xl font-semibold text-white mb-4">
                {step.title}
              </h3>
              <p className="text-gray-400">{step.description}</p>
            </div>
          ))}
        </div>

        <div className="mt-16 glass-panel p-8">
          <h2 className="text-2xl font-bold text-white mb-6">
            Our Technology
          </h2>
          <div className="space-y-4 text-gray-300">
            <p>
              Our deepfake detection system employs sophisticated machine learning
              algorithms trained on vast datasets of both authentic and manipulated
              media. The system analyzes various aspects of the content, including:
            </p>
            <ul className="list-disc list-inside space-y-2 ml-4">
              <li>Visual inconsistencies and artifacts</li>
              <li>Facial feature analysis</li>
              <li>Motion and behavior patterns</li>
              <li>Digital fingerprint examination</li>
            </ul>
            <p>
              This comprehensive approach allows us to identify potential
              manipulations with high accuracy, helping users verify the
              authenticity of their media content.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HowItWorks;
